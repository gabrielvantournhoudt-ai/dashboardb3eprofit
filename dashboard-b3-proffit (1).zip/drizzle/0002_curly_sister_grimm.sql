ALTER TABLE `winfut_cotacoes` MODIFY COLUMN `volumeTotal` varchar(50) NOT NULL;--> statement-breakpoint
ALTER TABLE `winfut_cotacoes` MODIFY COLUMN `variacaoPct` varchar(20);